using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using Sky_updater;
using System.Threading;

namespace Sky_encrypt
{
    public static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        public static void Main()
        {
            Application.SetHighDpiMode(HighDpiMode.SystemAware);
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            Thread thread = new Thread(new ThreadStart(CheckUpdate));
            thread.Priority = ThreadPriority.Highest;
            thread.Start();

            if (Path.GetExtension(Environment.GetCommandLineArgs().Last()) == ".ss2se")
            {
                List<string> vs = new List<string>();
                vs.Add(Path.GetFileName(Environment.GetCommandLineArgs().Last()));

                Crypto.Decrypt(vs, Path.GetDirectoryName(Environment.GetCommandLineArgs().Last()));

                vs.Clear();
                vs = null;
            }
            else
            {
                if (Environment.GetCommandLineArgs().Last() != Application.StartupPath + "Sky encrypt.dll" && Environment.GetCommandLineArgs().Last() != Application.ExecutablePath)
                {
                    MessageBox.Show("Ce fichier n'est pas chiffr� par Sky encrypt!", "Sky encrypt", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                Application.Run(new FormPrincipal());
            }
        }

        private static void CheckUpdate()
        {
            Update.CheckUpdate("Sky encrypt", Application.ProductVersion);
        }
    }
}
