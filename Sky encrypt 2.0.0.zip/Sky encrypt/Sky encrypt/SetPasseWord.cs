﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Sky_encrypt
{
    internal partial class SetPasseWord : Form
    {
        private bool FormCache = false;
        private int Coter = 0;
        private bool FormDeplace = false;
        private int LocX = 0;
        private int LocY = 0;
        private const int MiniLargeForm = 413;
        private const int MiniHautForm = 400;
        private bool PassewordIsSetP = false;

        internal SetPasseWord(ref string FileName)
        {
            InitializeComponent();

            this.Opacity = 0;
            timer1.Enabled = true;

            label1.Text += " - " + FileName;
        }

        #region FormConfig
        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            // animation de form arrêt ou démarre
            if (FormCache == false)
            {
                if (Opacity <= 0.99)
                {
                    Opacity += 0.05;
                }
                else
                {
                    timer1.Enabled = false;
                    FormCache = true;
                }
            }
            else
            {
                if (Opacity >= 0.01)
                {
                    Opacity -= 0.05;
                }
                else
                {
                    timer1.Enabled = false;
                    this.Hide();
                }
            }
        }

        private void FormPrincipal_FormClosing(object sender, FormClosingEventArgs e)
        {
            timer1.Enabled = true;
            e.Cancel = true;
        }

        private void FormPrincipal_MouseDown(object sender, MouseEventArgs e)
        {
            // déplacement active car souris préssée
            if (e.Button == MouseButtons.Left && this.Cursor == Cursors.Default)
            {
                LocX = e.X;
                LocY = e.Y;

                FormDeplace = true;
                return;
            }

            if (this.Cursor != Cursors.Default)
            {
                /// Coin :

                if (e.X >= this.Size.Width - 2 && e.Y >= this.Size.Height - 2)
                {
                    // agrandit ou réduit coin bas droite
                    Coter = 8;
                    timer2.Enabled = true;
                    return;
                }

                if (e.X <= 2 && e.Y >= this.Size.Height - 2)
                {
                    // agrandit ou réduit coin bas gauche
                    Coter = 7;
                    timer2.Enabled = true;
                    return;
                }

                if (e.X >= this.Size.Width - 2 && e.Y <= 2)
                {
                    // agrandit ou réduit coin haut droite
                    Coter = 5;
                    timer2.Enabled = true;
                    return;
                }

                if (e.X <= 2 && e.Y <= 2)
                {
                    // agrandit ou réduit coin haut gauche
                    Coter = 6;
                    timer2.Enabled = true;
                    return;
                }

                /// cotée :

                if (e.X == 0)
                {
                    // agrandit ou réduit coté gauche

                    Coter = 2;
                    timer2.Enabled = true;
                    return;
                }

                if (e.X == this.Size.Width - 1)
                {
                    // agrandit ou réduit coté droite

                    Coter = 1;
                    timer2.Enabled = true;
                    return;
                }

                if (e.Y == this.Size.Height - 1)
                {
                    // agrandit ou réduit coté bas
                    Coter = 4;
                    timer2.Enabled = true;
                    return;
                }

                if (e.Y == 0)
                {
                    // agrandit ou réduit coté haut
                    Coter = 3;
                    timer2.Enabled = true;
                    return;
                }
            }
        }

        private void FormPrincipal_MouseUp(object sender, MouseEventArgs e)
        {
            timer2.Enabled = false;
            Coter = 0;
            FormDeplace = false;
        }

        private void FormPrincipal_MouseMove(object sender, MouseEventArgs e)
        {
            // déplacement de la fenêtre
            if (FormDeplace == true)
            {
                this.Location = new Point(MousePosition.X - LocX, MousePosition.Y - LocY);
            }

            this.Cursor = Cursors.Default;
            button2.Cursor = Cursors.Default;

            if (e.X >= this.Size.Width - 2 && e.Y >= this.Size.Height - 2)
            {
                // agrandit ou réduit coin bas droite
                this.Cursor = Cursors.SizeNWSE;
                return;
            }

            if (e.X <= 2 && e.Y >= this.Size.Height - 2)
            {
                // agrandit ou réduit coin bas gauche
                this.Cursor = Cursors.SizeNESW;
                return;
            }

            if (e.X <= 2 && e.Y <= 2)
            {
                // agrandit ou réduit coin haut gauche
                this.Cursor = Cursors.SizeNWSE;
                return;
            }

            if (e.X == this.Size.Width - 1)
            {
                // agrandit ou réduit coté droite
                this.Cursor = Cursors.SizeWE;
                button2.Cursor = Cursors.SizeWE;
                return;
            }

            if (e.X == 0)
            {
                // agrandit ou réduit coté gauche
                this.Cursor = Cursors.SizeWE;
                return;
            }

            if (e.Y == this.Size.Height - 1)
            {
                // agrandit ou réduit coté bas
                this.Cursor = Cursors.SizeNS;
                return;
            }

            if (e.Y == 0)
            {
                // agrandit ou réduit coté haut
                this.Cursor = Cursors.SizeNS;
                button2.Cursor = Cursors.SizeNS;
                return;
            }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            switch (Coter)
            {
                case 1:  // côtée droit
                    if (MousePosition.X - this.Location.X >= MiniLargeForm)
                    {
                        this.Size = new Size(MousePosition.X - this.Location.X, this.Size.Height);
                    }
                    else
                    {
                        this.Size = new Size(MiniLargeForm, this.Size.Height);
                    }
                    break;

                case 2: // côtée gauche
                    if (this.Size.Width - (MousePosition.X - this.Location.X) >= MiniLargeForm)
                    {
                        this.Size = new Size(this.Size.Width - (MousePosition.X - this.Location.X), this.Size.Height);
                        this.Location = new Point(MousePosition.X, this.Location.Y);
                    }
                    else
                    {
                        this.Size = new Size(MiniLargeForm, this.Size.Height);
                    }
                    break;

                case 3:  // côtée haut
                    if (this.Size.Height - (MousePosition.Y - this.Location.Y) >= MiniHautForm)
                    {
                        this.Size = new Size(this.Size.Width, this.Size.Height - (MousePosition.Y - this.Location.Y));
                        this.Location = new Point(this.Location.X, MousePosition.Y);
                    }
                    else
                    {
                        this.Size = new Size(this.Size.Width, MiniHautForm);
                    }
                    break;

                case 4:  // côtée bas
                    if (MousePosition.Y - this.Location.Y >= MiniHautForm)
                    {
                        this.Size = new Size(this.Size.Width, MousePosition.Y - this.Location.Y);
                    }
                    else
                    {
                        this.Size = new Size(this.Size.Width, MiniHautForm);
                    }
                    break;

                case 5:  // coin haut droit
                    if (MousePosition.X - this.Location.X >= MiniLargeForm && this.Size.Height - (MousePosition.Y - this.Location.Y) >= MiniHautForm)
                    {
                        this.Size = new Size(MousePosition.X - this.Location.X, this.Size.Height - (MousePosition.Y - this.Location.Y));
                        this.Location = new Point(this.Location.X, MousePosition.Y);
                    }
                    else if (MousePosition.X - this.Location.X >= MiniLargeForm)
                    {
                        this.Size = new Size(MousePosition.X - this.Location.X, MiniHautForm);
                    }
                    else if (this.Size.Height - (MousePosition.Y - this.Location.Y) >= MiniHautForm)
                    {
                        this.Size = new Size(MiniLargeForm, this.Size.Height - (MousePosition.Y - this.Location.Y));
                        this.Location = new Point(this.Location.X, MousePosition.Y);
                    }
                    else
                    {
                        this.Size = new Size(MiniLargeForm, MiniHautForm);
                    }
                    break;

                case 6:  // coin haut gauche
                    if (this.Size.Width - (MousePosition.X - this.Location.X) >= MiniLargeForm && this.Size.Height - (MousePosition.Y - this.Location.Y) >= MiniHautForm)
                    {
                        this.Size = new Size(this.Size.Width - (MousePosition.X - this.Location.X), this.Size.Height - (MousePosition.Y - this.Location.Y));
                        this.Location = new Point(MousePosition.X, MousePosition.Y);
                    }
                    else if (this.Size.Width - (MousePosition.X - this.Location.X) >= MiniLargeForm)
                    {
                        this.Size = new Size(this.Size.Width - (MousePosition.X - this.Location.X), MiniHautForm);
                        this.Location = new Point(MousePosition.X, this.Location.Y);
                    }
                    else if (this.Size.Height - (MousePosition.Y - this.Location.Y) >= MiniHautForm)
                    {
                        this.Size = new Size(MiniLargeForm, this.Size.Height - (MousePosition.Y - this.Location.Y));
                        this.Location = new Point(this.Location.X, MousePosition.Y);
                    }
                    else
                    {
                        this.Size = new Size(MiniLargeForm, MiniHautForm);
                    }
                    break;

                case 7:  // coin bas gauche
                    if (this.Size.Width - (MousePosition.X - this.Location.X) >= MiniLargeForm && MousePosition.Y - this.Location.Y >= MiniHautForm)
                    {
                        this.Size = new Size(this.Size.Width - (MousePosition.X - this.Location.X), MousePosition.Y - this.Location.Y);
                        this.Location = new Point(MousePosition.X, this.Location.Y);
                    }
                    else if (this.Size.Width - (MousePosition.X - this.Location.X) >= MiniLargeForm)
                    {
                        this.Size = new Size(this.Size.Width - (MousePosition.X - this.Location.X), MiniHautForm);
                        this.Location = new Point(MousePosition.X, this.Location.Y);
                    }
                    else if (MousePosition.Y - this.Location.Y >= MiniHautForm)
                    {
                        this.Size = new Size(MiniLargeForm, MousePosition.Y - this.Location.Y);
                    }
                    else
                    {
                        this.Size = new Size(MiniLargeForm, MiniHautForm);
                    }
                    break;

                case 8:  // coin bas droit
                    if (MousePosition.X - this.Location.X >= MiniLargeForm && MousePosition.Y - this.Location.Y >= MiniHautForm)
                    {
                        this.Size = new Size(MousePosition.X - this.Location.X, MousePosition.Y - this.Location.Y);
                    }
                    else if (MousePosition.X - this.Location.X >= MiniLargeForm)
                    {
                        this.Size = new Size(MousePosition.X - this.Location.X, MiniHautForm);
                    }
                    else if (MousePosition.Y - this.Location.Y >= MiniHautForm)
                    {
                        this.Size = new Size(MiniLargeForm, MousePosition.Y - this.Location.Y);
                    }
                    else
                    {
                        this.Size = new Size(MiniLargeForm, MiniHautForm);
                    }
                    break;
            }
        }

        private void button1_MouseMove(object sender, MouseEventArgs e)
        {
            button2.Cursor = Cursors.Default;


            if (e.X >= button1.Size.Width - 2 && e.Y <= 2)
            {
                // agrandit ou réduit coin haut droite
                button1.Cursor = Cursors.SizeNESW;
                return;
            }

            if (e.X == button1.Size.Width - 1)
            {
                // droite
                button1.Cursor = Cursors.SizeWE;
                return;
            }

            if (e.Y == 1)
            {
                // haut
                button1.Cursor = Cursors.SizeNS;
                return;
            }
        }

        private void button1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.X >= button1.Size.Width - 2 && e.Y <= 2)
            {
                // agrandit ou réduit coin haut droite
                Coter = 5;
                timer2.Enabled = true;
                return;
            }

            if (e.X == button1.Size.Width - 2)
            {
                // agrandit ou réduit coté droite

                Coter = 1;
                timer2.Enabled = true;
                return;
            }

            if (e.Y == 1)
            {
                // agrandit ou réduit coté haut
                Coter = 3;
                timer2.Enabled = true;
                return;
            }
        }
        #endregion       

        private void button4_Click(object sender, EventArgs e)
        {
            // cancel
            timer1.Enabled = true; // close dialog
        }

        private void button5_Click(object sender, EventArgs e)
        {
            // continue

            if (textBox1.Text == textBox2.Text)
            {
                if (textBox1.Text.Length >= 8)
                {
                    PassewordIsSetP = true;
                    timer1.Enabled = true;  // close dialog
                }
                else
                {
                    MessageBox.Show("Il n'y a pas assez de caractères!", "Sky encrypt", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Les mots de passes ne sont pas identiques!", "Sky encrypt", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        internal bool PassewordIsSet()
        {
            return PassewordIsSetP;         
        }

        internal string PasseWord()
        {
            // envoi clé
            return textBox1.Text;
        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Return)
            {
                textBox2.Select();
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (textBox1.UseSystemPasswordChar == true)
            {
                textBox1.UseSystemPasswordChar = false;
            }
            else
            {
                textBox1.UseSystemPasswordChar = true;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (textBox2.UseSystemPasswordChar == true)
            {
                textBox2.UseSystemPasswordChar = false;
            }
            else
            {
                textBox2.UseSystemPasswordChar = true;
            }
        }

        private void textBox2_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Return)
            {
                if (textBox1.Text == textBox2.Text)
                {
                    if (textBox1.Text.Length >= 8)
                    {
                        PassewordIsSetP = true;
                        timer1.Enabled = true;  // close dialog
                    }
                    else
                    {
                        MessageBox.Show("Il n'y a pas assez de caractères!", "Sky encrypt", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Les mots de passes ne sont pas identiques!", "Sky encrypt", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}
