﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Security.Cryptography;
using System.IO;
using System.IO.Compression;
using System.Threading;

namespace Sky_encrypt
{
    internal static class Crypto
    {
        private static Loading loading = new Loading();

        internal static void Encrypt(List<string> FileSelect, string PathFile)
        {
            // chiffrer élément
            bool MemeClee = MessageBox.Show("Voulez vous utilisez la même clée pour tous les éléments sélectionnés?", "Sky encrypt", MessageBoxButtons.YesNo,
                MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes;

            string key = string.Empty;

            if (MemeClee == true)
            {
                key = SetKey();

                if (key == string.Empty)
                {
                    return;
                }
            }

            foreach (string i in FileSelect)
            {
                if (MemeClee == false)
                {
                    if (File.Exists(i))
                    {
                        key = SetKey(Path.GetFileName(i));
                    }
                    else
                    {
                        key = SetKey(new DirectoryInfo(i).Name);
                    }

                    if (key == string.Empty)
                    {
                        return;
                    }
                }

                string NamePath = "$$$";

                while (Directory.Exists(PathFile + @"\" + i + NamePath))
                {
                    NamePath += "$";
                }

                Directory.CreateDirectory(PathFile + @"\" + i + NamePath);

                if (Directory.Exists(PathFile + @"\" + i))
                {
                    Directory.Move(PathFile + @"\" + i, PathFile + @"\" + i + NamePath + @"\" + i);
                }
                else if (File.Exists(PathFile + @"\" + i))
                {
                    File.Move(PathFile + @"\" + i, PathFile + @"\" + i + NamePath + @"\" + i);
                }

                string NamePath2 = string.Empty;
                while (File.Exists(PathFile + @"\" + i + NamePath2 + ".zip"))
                {
                    NamePath2 += "$";
                }
                ZipFile.CreateFromDirectory(PathFile + @"\" + i + NamePath, PathFile + @"\" + i + NamePath2 + ".zip");

                if (Directory.Exists(PathFile + @"\" + i + NamePath))
                {
                    try
                    {
                        Directory.Delete(PathFile + @"\" + i + NamePath, true);
                    }
                    catch
                    {
                        // erreur
                    }
                }

                string NamePath3 = string.Empty;
                while (File.Exists(PathFile + @"\" + i + NamePath3 + ".ss2se"))
                {
                    NamePath3 += "$";
                }

                EncryptFile(PathFile + @"\" + i + NamePath2 + ".zip", PathFile + @"\" + i + NamePath3 + ".ss2se", key);

                if (File.Exists(PathFile + @"\" + i + NamePath2 + ".zip"))
                {
                    File.Delete(PathFile + @"\" + i + NamePath2 + ".zip");
                }

                if (MemeClee == false)
                {
                    loading.CloseLoading = true;
                }
            }

            loading.CloseLoading = true;
        }

        internal static void Decrypt(List<string> FileSelect, string PathFile)
        {
            // déchiffrer un fichier
            foreach (string i22 in FileSelect)
            {
                if (Path.GetExtension(PathFile + @"\" + i22) == ".ss2se")
                {
                    string NamePath = string.Empty;

                    while (File.Exists(PathFile + @"\" + NamePath + Path.GetFileNameWithoutExtension(i22) + ".zip"))
                    {
                        NamePath += "$";
                    }

                    string i2 = NamePath + Path.GetFileNameWithoutExtension(i22);
                    if (EnterPasseWord(i22, i2, false, PathFile) == false)
                    {
                        return;
                    }

                    Thread thread = new Thread(new ThreadStart(ThreadLoading));
                    thread.Start();

                    if (File.Exists(PathFile + @"\" + i22))
                    {
                        File.Delete(PathFile + @"\" + i22);
                    }
                    else if (Directory.Exists(PathFile + @"\" + i22))
                    {
                        Directory.Delete(PathFile + @"\" + i22, true);
                    }

                    string NamePath2 = "$";

                    while (File.Exists(PathFile + @"\" + i2 + NamePath2))
                    {
                        NamePath2 += "$";
                    }

                    ZipFile.ExtractToDirectory(PathFile + @"\" + i2 + ".zip", PathFile + @"\" + i2 + NamePath2);

                    if (File.Exists(PathFile + @"\" + i2 + ".zip"))
                    {
                        File.Delete(PathFile + @"\" + i2 + ".zip");
                    }

                    foreach (string i in Directory.EnumerateDirectories(PathFile + @"\" + i2 + NamePath2))
                    {
                        if (Directory.Exists(i))
                        {
                            Directory.Move(i, PathFile + @"\" + i2);
                            Directory.Delete(PathFile + @"\" + i2 + NamePath2, true);
                        }
                    }

                    if (Directory.Exists(PathFile + @"\" + i2 + NamePath2))   // conddition obligatoire car verif si déjà supprimer
                    {
                        foreach (string i in Directory.EnumerateFiles(PathFile + @"\" + i2 + NamePath2))
                        {
                            if (File.Exists(i))
                            {
                                File.Move(i, PathFile + @"\" + i2);
                                Directory.Delete(PathFile + @"\" + i2 + NamePath2);
                            }
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Ce n'est pas la bonne extension de fichier ce n'est donc pas sky encrypt qui a chiffré ce fichier!", "Sky encrypt", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                loading.CloseLoading = true;
            }
        }

        private static string SetKey(string FileName = "")
        {
            SetPasseWord setPasseWord = new SetPasseWord(ref FileName);
            setPasseWord.ShowDialog();
            if (setPasseWord.PassewordIsSet() == false)
            {
                setPasseWord.Dispose();
                setPasseWord = null;
                return string.Empty;
            }
            string Key = setPasseWord.PasseWord();
            setPasseWord.Dispose();
            setPasseWord = null;

            Thread thread = new Thread(new ThreadStart(ThreadLoading));
            thread.Start();
            return Key;
        }

        private static bool EnterPasseWord(string File, string Extensions, bool ErrorKey, string PathFile)
        {
            return EnterPasseWord(ref File, ref Extensions, ref ErrorKey, ref PathFile);
        }

        private static bool EnterPasseWord(ref string File, ref string Extensions, ref bool ErrorKey, ref string PathFile)
        {
            EnterPasseWord enterPasseWord = new EnterPasseWord(ErrorKey, File);
            enterPasseWord.ShowDialog();
            if (enterPasseWord.PassewordIsEnted() == false)
            {
                enterPasseWord.Dispose();
                enterPasseWord = null;
                return false;
            }
            string Key = enterPasseWord.PasseWord();
            enterPasseWord.Dispose();
            enterPasseWord = null;

            if (DecryptFile(PathFile + @"\" + File, PathFile + @"\" + Extensions + ".zip", Key) == false)
            {
                ErrorKey = true;
                return EnterPasseWord(ref File, ref Extensions, ref ErrorKey, ref PathFile);
            }

            return true;
        }

        private static void ThreadLoading()
        {
            loading.CreateThreadClose();
            loading.ShowDialog();
        }

        // Rfc2898DeriveBytes constants:
        private static readonly byte[] salt = new byte[] { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };
        private static int iterations = 11042;

        /// <summary>Decrypt a file.</summary>
        /// <remarks>NB: "Padding is invalid and cannot be removed." is the Universal CryptoServices error.  Make sure the password, salt and iterations are correct before getting nervous.</remarks>
        /// <param name="sourceFilename">The full path and name of the file to be decrypted.</param>
        /// <param name="destinationFilename">The full path and name of the file to be output.</param>
        /// <param name="password">The password for the decryption.</param>
        /// <param name="salt">The salt to be applied to the password.</param>
        /// <param name="iterations">The number of iterations Rfc2898DeriveBytes should use before generating the key and initialization vector for the decryption.</param>
        private static bool DecryptFile(string sourceFilename, string destinationFilename, string password)
        {
            AesManaged aes = new AesManaged();
            aes.BlockSize = aes.LegalBlockSizes[0].MaxSize;
            aes.KeySize = aes.LegalKeySizes[0].MaxSize;
            Rfc2898DeriveBytes key = new Rfc2898DeriveBytes(password, salt, iterations);
            aes.Key = key.GetBytes(aes.KeySize / 8);
            aes.IV = key.GetBytes(aes.BlockSize / 8);
            aes.Mode = CipherMode.CBC;
            ICryptoTransform transform = aes.CreateDecryptor(aes.Key, aes.IV);

            aes.Clear();
            aes.Dispose();
            aes = null;

            key.Dispose();
            key = null;

            using (FileStream destination = new FileStream(destinationFilename, FileMode.CreateNew, FileAccess.Write, FileShare.None))
            {
                try
                {
                    using (CryptoStream cryptoStream = new CryptoStream(destination, transform, CryptoStreamMode.Write))
                    {
                        try
                        {
                            using (FileStream source = new FileStream(sourceFilename, FileMode.Open, FileAccess.Read, FileShare.Read))
                            {
                                source.CopyTo(cryptoStream);
                                source.Close();
                            }
                        }
                        catch (CryptographicException exception)
                        {
                            if (exception.Message == "Padding is invalid and cannot be removed.")
                                throw new ApplicationException("Universal Microsoft Cryptographic Exception (Not to be believed!)", exception);
                            else
                                throw;
                        }
                        cryptoStream.Close();
                        destination.Close();
                    }
                    return true;
                }
                catch
                {
                    destination.Close();
                    if (File.Exists(destinationFilename))
                    {
                        File.Delete(destinationFilename);
                    }
                    return false;
                }
            }
        }

        /// <summary>Encrypt a file.</summary>
        /// <param name="sourceFilename">The full path and name of the file to be encrypted.</param>
        /// <param name="destinationFilename">The full path and name of the file to be output.</param>
        /// <param name="password">The password for the encryption.</param>
        /// <param name="salt">The salt to be applied to the password.</param>
        /// <param name="iterations">The number of iterations Rfc2898DeriveBytes should use before generating the key and initialization vector for the decryption.</param>
        private static void EncryptFile(string sourceFilename, string destinationFilename, string password)
        {
            AesManaged aes = new AesManaged();
            aes.BlockSize = aes.LegalBlockSizes[0].MaxSize;
            aes.KeySize = aes.LegalKeySizes[0].MaxSize;
            Rfc2898DeriveBytes key = new Rfc2898DeriveBytes(password, salt, iterations);
            aes.Key = key.GetBytes(aes.KeySize / 8);
            aes.IV = key.GetBytes(aes.BlockSize / 8);
            aes.Mode = CipherMode.CBC;
            ICryptoTransform transform = aes.CreateEncryptor(aes.Key, aes.IV);

            aes.Clear();
            aes.Dispose();
            aes = null;

            key.Dispose();
            key = null;

            using (FileStream destination = new FileStream(destinationFilename, FileMode.CreateNew, FileAccess.Write, FileShare.None))
            {
                using (CryptoStream cryptoStream = new CryptoStream(destination, transform, CryptoStreamMode.Write))
                {
                    using (FileStream source = new FileStream(sourceFilename, FileMode.Open, FileAccess.Read, FileShare.Read))
                    {
                        source.CopyTo(cryptoStream);

                        cryptoStream.Close();
                        destination.Close();
                        source.Close();
                    }
                }
            }
        }
    }
}
