﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sky_encrypt
{
    internal delegate void EventCliqueIDHandler(ref int ID);

    internal partial class ButtonDisk : UserControl
    {
        internal EventCliqueIDHandler EventCliqueID = null;
        internal int ID = 0;

        internal ButtonDisk(string NameDisk, string TailleDisk)
        {
            InitializeComponent();

            label1.Text = NameDisk;
            label2.Text = TailleDisk;
        }

        internal string NameDisk
        {
            get
            {
                return label1.Text;
            }
        }

        private void pictureBox1_MouseEnter(object sender, EventArgs e)
        {
            this.BackColor = Color.FromArgb(100, 100, 100);
        }

        private void label1_MouseEnter(object sender, EventArgs e)
        {
            this.BackColor = Color.FromArgb(100, 100, 100);
        }

        private void label2_MouseEnter(object sender, EventArgs e)
        {
            this.BackColor = Color.FromArgb(100, 100, 100);
        }

        private void ButtonDisk_MouseEnter(object sender, EventArgs e)
        {
            this.BackColor = Color.FromArgb(100, 100, 100);
        }

        private void pictureBox1_MouseLeave(object sender, EventArgs e)
        {
            this.BackColor = Color.FromArgb(64, 64, 64);
        }

        private void label1_MouseLeave(object sender, EventArgs e)
        {
            this.BackColor = Color.FromArgb(64, 64, 64);
        }

        private void label2_MouseLeave(object sender, EventArgs e)
        {
            this.BackColor = Color.FromArgb(64, 64, 64);
        }

        private void ButtonDisk_MouseLeave(object sender, EventArgs e)
        {
            this.BackColor = Color.FromArgb(64, 64, 64);
        }

        private void ButtonDisk_MouseClick(object sender, MouseEventArgs e)
        {
            EventCliqueIDExecuted(ID);
        }

        private void pictureBox1_MouseClick(object sender, MouseEventArgs e)
        {
            EventCliqueIDExecuted(ID);
        }

        private void label1_MouseClick(object sender, MouseEventArgs e)
        {
            EventCliqueIDExecuted(ID);
        }

        private void label2_MouseClick(object sender, MouseEventArgs e)
        {
            EventCliqueIDExecuted(ID);
        }

        protected virtual void EventCliqueIDExecuted(int ID)
        {
            if (EventCliqueID != null)
            {
                EventCliqueID(ref ID);
            }
        }
    }
}
