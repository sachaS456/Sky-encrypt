﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Security.Cryptography;
using System.IO;
using System.IO.Compression;
using System.Threading;

namespace Sky_encrypt
{
    internal static class Crypto
    {
        private static Loading loading = new Loading();

        internal static void Encrypt(List<string> FileSelect, string PathFile, sbyte lang, bool explorer = false)
        {
            // chiffrer élément

            bool MemeClee;
            loading.SetLanguage(lang);

            if (explorer || FileSelect.Count() == 1)
            {
                MemeClee = false;
            }
            else
            {
                if (lang == 0)
                {
                    MemeClee = MessageBox.Show("Voulez vous utilisez la même clé pour tous les éléments sélectionnés?", "Sky encrypt", MessageBoxButtons.YesNo,
    MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes;
                }
                else
                {
                    MemeClee = MessageBox.Show("Do you want to use the same key for all selected items?", "Sky encrypt", MessageBoxButtons.YesNo,
    MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes;
                }
            }

            CryptoConfig keyConfig = CryptoConfig.Empty;

            if (MemeClee == true)
            {
                keyConfig = SetKey(ref lang);

                if (keyConfig.KeyIsEmpty)
                {
                    return;
                }
            }

            foreach (string i in FileSelect)
            {
                if (MemeClee == false)
                {
                    if (File.Exists(i))
                    {
                        keyConfig = SetKey(ref lang, Path.GetFileName(i));
                    }
                    else
                    {
                        keyConfig = SetKey(ref lang, new DirectoryInfo(i).Name);
                    }

                    if (keyConfig.KeyIsEmpty)
                    {
                        return;
                    }
                }

                string NamePath = "$$$";

                while (Directory.Exists(PathFile + @"\" + i + NamePath))
                {
                    NamePath += "$";
                }

                Directory.CreateDirectory(PathFile + @"\" + i + NamePath);

                if (Directory.Exists(PathFile + @"\" + i))
                {
                    Directory.Move(PathFile + @"\" + i, PathFile + @"\" + i + NamePath + @"\" + i);
                }
                else if (File.Exists(PathFile + @"\" + i))
                {
                    File.Move(PathFile + @"\" + i, PathFile + @"\" + i + NamePath + @"\" + i);
                }

                string NamePath2 = string.Empty;
                while (File.Exists(PathFile + @"\" + i + NamePath2 + ".zip"))
                {
                    NamePath2 += "$";
                }
                ZipFile.CreateFromDirectory(PathFile + @"\" + i + NamePath, PathFile + @"\" + i + NamePath2 + ".zip");

                if (Directory.Exists(PathFile + @"\" + i + NamePath))
                {
                    try
                    {
                        Directory.Delete(PathFile + @"\" + i + NamePath, true);
                    }
                    catch
                    {
                        // erreur
                    }
                }

                string NamePath3 = string.Empty;
                while (File.Exists(PathFile + @"\" + i + NamePath3 + ".ss2se"))
                {
                    NamePath3 += "$";
                }

                EncryptFile(PathFile + @"\" + i + NamePath2 + ".zip", PathFile + @"\" + i + NamePath3 + ".ss2se", keyConfig.Key, keyConfig.Algo);

                if (File.Exists(PathFile + @"\" + i + NamePath2 + ".zip"))
                {
                    File.Delete(PathFile + @"\" + i + NamePath2 + ".zip");
                }

                if (MemeClee == false)
                {
                    loading.CloseLoading = true;
                }
            }

            loading.CloseLoading = true;
        }

        internal static void Decrypt(List<string> FileSelect, string PathFile, sbyte lang)
        {
            // déchiffrer un fichier

            loading.SetLanguage(lang);

            foreach (string i22 in FileSelect)
            {
                if (Path.GetExtension(PathFile + @"\" + i22) == ".ss2se")
                {
                    string NamePath = string.Empty;

                    while (File.Exists(PathFile + @"\" + NamePath + Path.GetFileNameWithoutExtension(i22) + ".zip"))
                    {
                        NamePath += "$";
                    }

                    string i2 = NamePath + Path.GetFileNameWithoutExtension(i22);
                    if (EnterPasseWord(i22, i2, false, PathFile, ref lang) == false)
                    {
                        return;
                    }

                    Thread thread = new Thread(new ThreadStart(ThreadLoading));
                    thread.Start();

                    if (File.Exists(PathFile + @"\" + i22))
                    {
                        File.Delete(PathFile + @"\" + i22);
                    }
                    else if (Directory.Exists(PathFile + @"\" + i22))
                    {
                        Directory.Delete(PathFile + @"\" + i22, true);
                    }

                    string NamePath2 = "$";

                    while (File.Exists(PathFile + @"\" + i2 + NamePath2))
                    {
                        NamePath2 += "$";
                    }

                    ZipFile.ExtractToDirectory(PathFile + @"\" + i2 + ".zip", PathFile + @"\" + i2 + NamePath2);

                    if (File.Exists(PathFile + @"\" + i2 + ".zip"))
                    {
                        File.Delete(PathFile + @"\" + i2 + ".zip");
                    }

                    foreach (string i in Directory.EnumerateDirectories(PathFile + @"\" + i2 + NamePath2))
                    {
                        if (Directory.Exists(i))
                        {
                            Directory.Move(i, PathFile + @"\" + i2);
                            Directory.Delete(PathFile + @"\" + i2 + NamePath2, true);
                        }
                    }

                    if (Directory.Exists(PathFile + @"\" + i2 + NamePath2))   // conddition obligatoire car verif si déjà supprimer
                    {
                        foreach (string i in Directory.EnumerateFiles(PathFile + @"\" + i2 + NamePath2))
                        {
                            if (File.Exists(i))
                            {
                                File.Move(i, PathFile + @"\" + i2);
                                Directory.Delete(PathFile + @"\" + i2 + NamePath2);
                            }
                        }
                    }
                }
                else
                {
                    if (lang == 0)
                    {
                        MessageBox.Show("Ce n'est pas la bonne extension de fichier ce n'est donc pas sky encrypt qui a chiffré ce fichier!", "Sky encrypt", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        MessageBox.Show("This is not the correct file extension so it was not sky encrypt that encrypted this file!", "Sky encrypt", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }

                loading.CloseLoading = true;
            }
        }

        private static CryptoConfig SetKey(ref sbyte lang, string FileName = "")
        {
            SetPasseWord setPasseWord = new SetPasseWord(ref FileName, lang);
            setPasseWord.ShowDialog();
            if (setPasseWord.PassewordIsSet() == false)
            {
                setPasseWord.Dispose();
                setPasseWord = null;
                return CryptoConfig.Empty;
            }
            CryptoConfig Key = setPasseWord.PasseWord();
            setPasseWord.Dispose();
            setPasseWord = null;

            Thread thread = new Thread(new ThreadStart(ThreadLoading));
            thread.Start();
            return Key;
        }

        private static bool EnterPasseWord(string File, string Extensions, bool ErrorKey, string PathFile, ref sbyte lang)
        {
            return EnterPasseWord(ref File, ref Extensions, ref ErrorKey, ref PathFile, ref lang);
        }

        private static bool EnterPasseWord(ref string File, ref string Extensions, ref bool ErrorKey, ref string PathFile, ref sbyte lang)
        {
            EnterPasseWord enterPasseWord = new EnterPasseWord(ErrorKey, File, lang);
            enterPasseWord.ShowDialog();
            if (enterPasseWord.PassewordIsEnted() == false)
            {
                enterPasseWord.Dispose();
                enterPasseWord = null;
                return false;
            }
            string Key = enterPasseWord.PasseWord();
            enterPasseWord.Dispose();
            enterPasseWord = null;

            bool PassewordCorrect = false;

            for (sbyte index = 0; index <= 3; index++)
            {
                if (DecryptFile(PathFile + @"\" + File, PathFile + @"\" + Extensions + ".zip", Key, index) == true)
                {
                    PassewordCorrect = true;
                    break;
                }
                else
                {
                    PassewordCorrect = false;
                }
            }

            if (PassewordCorrect == false)
            {
                ErrorKey = true;
                return EnterPasseWord(ref File, ref Extensions, ref ErrorKey, ref PathFile, ref lang);
            }

            return true;
        }

        private static void ThreadLoading()
        {
            loading.CreateThreadClose();
            loading.ShowDialog();
        }

        // Rfc2898DeriveBytes constants:
        private static readonly byte[] salt = new byte[] { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };
        private static int iterations = 11042;

        /// <summary>Decrypt a file.</summary>
        /// <remarks>NB: "Padding is invalid and cannot be removed." is the Universal CryptoServices error.  Make sure the password, salt and iterations are correct before getting nervous.</remarks>
        /// <param name="sourceFilename">The full path and name of the file to be decrypted.</param>
        /// <param name="destinationFilename">The full path and name of the file to be output.</param>
        /// <param name="password">The password for the decryption.</param>
        /// <param name="salt">The salt to be applied to the password.</param>
        /// <param name="iterations">The number of iterations Rfc2898DeriveBytes should use before generating the key and initialization vector for the decryption.</param>
        private static bool DecryptFile(string sourceFilename, string destinationFilename, string password, sbyte Algo)
        {
            ICryptoTransform transform;
            Rfc2898DeriveBytes key = new Rfc2898DeriveBytes(password, salt, iterations);

            switch (Algo)
            {
                case Algoritme.AES:

                    transform = AESConfig(ref key, true);

                    break;

                case Algoritme.DES:

                    DES des = new DESCryptoServiceProvider();
                    des.BlockSize = des.LegalBlockSizes[0].MaxSize;
                    des.KeySize = des.LegalKeySizes[0].MaxSize;
                    des.Key = key.GetBytes(des.KeySize / 8);
                    des.IV = key.GetBytes(des.BlockSize / 8);
                    des.Mode = CipherMode.CBC;
                    transform = des.CreateDecryptor(des.Key, des.IV);

                    des.Clear();
                    des.Dispose();
                    des = null;

                    break;

                case Algoritme.RC2:

                    RC2CryptoServiceProvider rc2 = new RC2CryptoServiceProvider();
                    rc2.BlockSize = rc2.LegalBlockSizes[0].MaxSize;
                    rc2.KeySize = rc2.LegalKeySizes[0].MaxSize;
                    rc2.Key = key.GetBytes(rc2.KeySize / 8);
                    rc2.IV = key.GetBytes(rc2.BlockSize / 8);
                    rc2.Mode = CipherMode.CBC;
                    transform = rc2.CreateDecryptor(rc2.Key, rc2.IV);

                    rc2.Clear();
                    rc2.Dispose();
                    rc2 = null;

                    break;

                case Algoritme.TripleDES:

                    TripleDESCryptoServiceProvider tdes = new TripleDESCryptoServiceProvider();
                    tdes.BlockSize = tdes.LegalBlockSizes[0].MaxSize;
                    tdes.KeySize = tdes.LegalKeySizes[0].MaxSize;
                    tdes.Key = key.GetBytes(tdes.KeySize / 8);
                    tdes.IV = key.GetBytes(tdes.BlockSize / 8);
                    tdes.Mode = CipherMode.CBC;
                    transform = tdes.CreateDecryptor(tdes.Key, tdes.IV);

                    tdes.Clear();
                    tdes.Dispose();
                    tdes = null;

                    break;

                default:

                    transform = AESConfig(ref key, true);

                    break;
            }

            key.Dispose();
            key = null;

            using (FileStream destination = new FileStream(destinationFilename, FileMode.CreateNew, FileAccess.Write, FileShare.None))
            {
                try
                {
                    using (CryptoStream cryptoStream = new CryptoStream(destination, transform, CryptoStreamMode.Write))
                    {
                        try
                        {
                            using (FileStream source = new FileStream(sourceFilename, FileMode.Open, FileAccess.Read, FileShare.Read))
                            {
                                source.CopyTo(cryptoStream);
                                source.Close();
                            }
                        }
                        catch (CryptographicException exception)
                        {
                            if (exception.Message == "Padding is invalid and cannot be removed.")
                                throw new ApplicationException("Universal Microsoft Cryptographic Exception (Not to be believed!)", exception);
                            else
                                throw;
                        }
                        cryptoStream.Close();
                        destination.Close();
                    }
                    return true;
                }
                catch
                {
                    destination.Close();
                    if (File.Exists(destinationFilename))
                    {
                        File.Delete(destinationFilename);
                    }
                    return false;
                }
            }
        }

        /// <summary>Encrypt a file.</summary>
        /// <param name="sourceFilename">The full path and name of the file to be encrypted.</param>
        /// <param name="destinationFilename">The full path and name of the file to be output.</param>
        /// <param name="password">The password for the encryption.</param>
        /// <param name="salt">The salt to be applied to the password.</param>
        /// <param name="iterations">The number of iterations Rfc2898DeriveBytes should use before generating the key and initialization vector for the decryption.</param>
        private static void EncryptFile(string sourceFilename, string destinationFilename, string password, sbyte Algo)
        {
            ICryptoTransform transform;
            Rfc2898DeriveBytes key = new Rfc2898DeriveBytes(password, salt, iterations);

            switch (Algo)
            {
                case Algoritme.AES:

                    transform = AESConfig(ref key, false);

                    break;

                case Algoritme.DES:

                    DES des = new DESCryptoServiceProvider();
                    des.BlockSize = des.LegalBlockSizes[0].MaxSize;
                    des.KeySize = des.LegalKeySizes[0].MaxSize;
                    des.Key = key.GetBytes(des.KeySize / 8);
                    des.IV = key.GetBytes(des.BlockSize / 8);
                    des.Mode = CipherMode.CBC;
                    transform = des.CreateEncryptor(des.Key, des.IV);

                    des.Clear();
                    des.Dispose();
                    des = null;

                    break;

                case Algoritme.RC2:

                    RC2CryptoServiceProvider rc2 = new RC2CryptoServiceProvider();
                    rc2.BlockSize = rc2.LegalBlockSizes[0].MaxSize;
                    rc2.KeySize = rc2.LegalKeySizes[0].MaxSize;
                    rc2.Key = key.GetBytes(rc2.KeySize / 8);
                    rc2.IV = key.GetBytes(rc2.BlockSize / 8);
                    rc2.Mode = CipherMode.CBC;
                    transform = rc2.CreateEncryptor(rc2.Key, rc2.IV);

                    rc2.Clear();
                    rc2.Dispose();
                    rc2 = null;

                    break;

                case Algoritme.TripleDES:

                    TripleDESCryptoServiceProvider tdes = new TripleDESCryptoServiceProvider();
                    tdes.BlockSize = tdes.LegalBlockSizes[0].MaxSize;
                    tdes.KeySize = tdes.LegalKeySizes[0].MaxSize;
                    tdes.Key = key.GetBytes(tdes.KeySize / 8);
                    tdes.IV = key.GetBytes(tdes.BlockSize / 8);
                    tdes.Mode = CipherMode.CBC;
                    transform = tdes.CreateEncryptor(tdes.Key, tdes.IV);

                    tdes.Clear();
                    tdes.Dispose();
                    tdes = null;

                    break;

                default:

                    transform = AESConfig(ref key, false);

                    break;
            }

            key.Dispose();
            key = null;

            using (FileStream destination = new FileStream(destinationFilename, FileMode.CreateNew, FileAccess.Write, FileShare.None))
            {
                using (CryptoStream cryptoStream = new CryptoStream(destination, transform, CryptoStreamMode.Write))
                {
                    using (FileStream source = new FileStream(sourceFilename, FileMode.Open, FileAccess.Read, FileShare.Read))
                    {
                        source.CopyTo(cryptoStream);

                        cryptoStream.Close();
                        destination.Close();
                        source.Close();
                    }
                }
            }
        }

        private static ICryptoTransform AESConfig(ref Rfc2898DeriveBytes key, bool Decrypt)
        {
            AesManaged aes = new AesManaged();
            aes.BlockSize = aes.LegalBlockSizes[0].MaxSize;
            aes.KeySize = aes.LegalKeySizes[0].MaxSize;
            aes.Key = key.GetBytes(aes.KeySize / 8);
            aes.IV = key.GetBytes(aes.BlockSize / 8);
            aes.Mode = CipherMode.CBC;

            if (Decrypt == true)
            {
                return aes.CreateDecryptor(aes.Key, aes.IV);
            }
            else
            {
                return aes.CreateEncryptor(aes.Key, aes.IV);
            }
        }
    }
}
