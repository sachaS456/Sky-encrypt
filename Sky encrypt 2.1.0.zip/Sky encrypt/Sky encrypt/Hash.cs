﻿using System.Text;
using System.Security.Cryptography;

namespace Sky_encrypt
{
    internal static class Hash
    {
        internal static string GenerateSHA512String(string inputString)
        {
            SHA512 sha512 = SHA512Managed.Create();
            byte[] hash = sha512.ComputeHash(Encoding.UTF8.GetBytes(inputString));

            sha512.Clear();
            sha512.Dispose();
            sha512 = null;

            return GetStringFromHash(ref hash);
        }

        private static string GetStringFromHash(ref byte[] hash)
        {
            StringBuilder result = new StringBuilder();
            for (int i = 0; i < hash.Length; i++)
            {
                result.Append(hash[i].ToString("X2"));
            }
            return result.ToString();
        }
    }
}
