﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;

namespace Sky_encrypt
{
    internal partial class Reglage : Form
    {
        private bool FormCache = false;
        private bool FormDeplace = false;
        private int LocX = 0;
        private int LocY = 0;
        internal bool Save { get; private set; } = false;
        internal sbyte Language { get; private set; } = 0;

        internal Reglage()
        {
            InitializeComponent();

            comboBox1.Items.Add("Français");
            comboBox1.Items.Add("English");
            comboBox1.SelectedIndex = 0;
        }

        internal void Define(ref sbyte Lang)
        {
            if (Lang == 0)
            {
                label1.Text = "Langage :";
                label6.Text = "Reglages Sky encrypt";
                button1.Text = "Annuler";
                button4.Text = "Sauvegarder";
            }
            else
            {
                label1.Text = "Language :";
                label6.Text = "Settings Sky encrypt";
                button1.Text = "Cancel";
                button4.Text = "Save";
            }
            comboBox1.SelectedIndex = Lang;

            this.Opacity = 0;
            timer1.Enabled = true;
            this.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Save = false;
            timer1.Enabled = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Save = false;
            timer1.Enabled = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (FormCache == false)
            {
                if (Opacity <= 0.99)
                {
                    Opacity += 0.05;
                }
                else
                {
                    timer1.Enabled = false;
                    FormCache = true;
                }
            }
            else
            {
                if (Opacity >= 0.01)
                {
                    Opacity -= 0.05;
                }
                else
                {
                    timer1.Enabled = false;
                    FormCache = false;
                    this.Close();
                }
            }
        }

        private void panel3_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                LocX = e.X;
                LocY = e.Y;

                FormDeplace = true;
            }
        }

        private void panel3_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                FormDeplace = false;
            }
        }

        private void panel3_MouseMove(object sender, MouseEventArgs e)
        {
            if (FormDeplace == true)
            {
                this.Location = new Point(MousePosition.X - LocX, MousePosition.Y - LocY);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            // save
            Save = true;
            timer1.Enabled = true;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            // cancel
            Save = false;
            timer1.Enabled = true;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Language = (sbyte)comboBox1.SelectedIndex;
        }
    }
}
