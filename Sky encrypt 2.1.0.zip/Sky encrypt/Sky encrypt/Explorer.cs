﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;

namespace Sky_encrypt
{
    internal delegate void EventExplorerHandler(ref EventExplorerArgs e);

    internal partial class Explorer : UserControl
    {
        private string FileSelect = string.Empty;
        private List<ButtonDisk> buttonDisksList = new List<ButtonDisk>();
        internal event EventExplorerHandler PathChanger = null;
        internal sbyte lang { private get; set; } = 0;

        internal Explorer()
        {
            InitializeComponent();

            AddButtonDisk();
        }

        protected virtual void ExecuterEvenementPathChanger(EventExplorerArgs e)
        {
            if (PathChanger != null)
            {
                PathChanger(ref e);
            }
        }

        internal string CheminFichier
        {
            get
            {
                return FileSelect;
            }
        }

        internal List<string> FichierSelected()
        {
            List<string> ItemSelect = new List<string>();

            foreach (ListViewItem i in listView1.SelectedItems)
            {
                ItemSelect.Add(i.SubItems[0].Text);
            }

            return ItemSelect;           
        }

        internal void explorer(string cheminFichier)
        {
            SuppressButtonDisk();

            if (lang == 0)
            {
                listView1.Columns.Clear();
                this.NameE.Text = "Nom";
                this.Create_Date.Text = "Créé le";
                this.Type.Text = "Type";
                this.SizeE.Text = "Taille";
                listView1.Columns.AddRange(new ColumnHeader[] { this.NameE, this.Create_Date, this.Type, this.SizeE });
            }
            else
            {
                listView1.Columns.Clear();
                this.NameE.Text = "Name";
                this.Create_Date.Text = "Created the";
                this.Type.Text = "Type";
                this.SizeE.Text = "Size";
                listView1.Columns.AddRange(new ColumnHeader[] { this.NameE, this.Create_Date, this.Type, this.SizeE });
            }

            if (cheminFichier == string.Empty)
            {
                FileSelect = cheminFichier;
                listView1.Items.Clear(); // clear all items
                AddButtonDisk();
                return;
            }

            if (Directory.Exists(cheminFichier) == false)
            {
                if (lang == 0)
                {
                    MessageBox.Show("Veuillez entrer un chemin correct!", "Sky encrypt", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    MessageBox.Show("Please enter a correct path!", "Sky encrypt", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                return;
            }
            FileSelect = cheminFichier;
            listView1.Items.Clear(); // clear all items

            // liste pour les noms de fichiers
            List<string> FilePath;
            try
            {
                FilePath = new List<string>(Directory.EnumerateFiles(cheminFichier));
            }
            catch
            {
                FilePath = new List<string>();
            }

            List<string> DirectoryPath;
            try
            {
                DirectoryPath = new List<string>(Directory.EnumerateDirectories(cheminFichier));
            }
            catch
            {
                DirectoryPath = new List<string>();
            }

            //ImageList itemImage = new ImageList();

            // caratéristique du fichier
            List<string> FileName = new List<string>();
            List<string> FileType = new List<string>();
            List<string> FileSize = new List<string>();
            List<string> FileLastWriteTime = new List<string>();

            if (listView1.SmallImageList == null)
            {
                listView1.SmallImageList = new ImageList();
            }
            else
            {
                listView1.SmallImageList.Images.Clear();
            }

            foreach (string i in DirectoryPath)
            {
                if (Directory.Exists(i))
                {
                    FileName.Add(Path.GetFileName(i));

                    listView1.SmallImageList.Images.Add(Image.FromFile(Application.StartupPath + @"\SquareTile44x44.targetsize-48_altform-unplated_devicefamily-colorfulunplated.png"));                    

                    FileType.Add("Directory");
                    FileLastWriteTime.Add(Directory.GetLastWriteTime(i).ToString());
                    FileSize.Add("");
                }
            }

            foreach (string i in FilePath)
            {
                if (File.Exists(i))
                {
                    FileName.Add(Path.GetFileName(i));
                    try
                    {
                        listView1.SmallImageList.Images.Add(Icon.ExtractAssociatedIcon(i));                    
                    }
                    catch
                    {
                        // erreur
                    }
                }

                FileType.Add(Path.GetExtension(i));
                FileLastWriteTime.Add(File.GetLastWriteTime(i).ToString());

                try
                {
                    FileSize.Add(new FileInfo(i).Length.ToString());
                }
                catch
                {
                    FileSize.Add("");
                }
            }

            int nbItem = -1;

            try
            {
                nbItem = Directory.GetFiles(cheminFichier, "*.*", SearchOption.TopDirectoryOnly).Length + Directory.GetDirectories(cheminFichier, 
                    "*.*", SearchOption.TopDirectoryOnly).Length - 1;
            }
            catch (UnauthorizedAccessException)
            {
                nbItem = -1;
                if (lang == 0)
                {
                    MessageBox.Show("Accès refusés! Sky encrypt n'a pas l'autorisation d'accéder ou de modifier les éléments dans ce répertoire.", "Sky encrypt",
    MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    MessageBox.Show("Access denied! Sky encrypt does not have permission to access or modify items in this directory.", "Sky encrypt",
    MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

            //listView1.SmallImageList = itemImage;            

            for (int index = 0; index <= nbItem; index++)
            {
                ListViewItem item = new ListViewItem(FileName[index]);
                item.SubItems.Add(FileLastWriteTime[index]);
                item.SubItems.Add(FileType[index]);
                item.SubItems.Add(FileSize[index]);

                listView1.Items.Add(item);

                listView1.Items[index].ImageIndex = index;
            }
        }

        private void listView1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            bool OK = true;
            string FileName = string.Empty;

            foreach (ListViewItem i in listView1.Items)
            {
                if (i.Selected == true && OK == true)
                {
                    if (i.SubItems[2].Text == "Directory")
                    {
                        // dossier
                        OK = false;
                    }
                    else
                    {
                        // fichier
                        OK = true;
                    }
                    FileName = i.Text;
                }
            }

            if (OK == true)
            {
                // fichier
                Process process = new Process();
                process.StartInfo.UseShellExecute = true;
                process.StartInfo.FileName = FileSelect + @"\" + FileName;
                process.Start();
                process.Close();
                process = null;
            }
            else
            {
                // dossier
                ExecuterEvenementPathChanger(new EventExplorerArgs(FileSelect + @"\" + FileName));
                explorer(FileSelect + @"\" + FileName);
            }
        }

        internal void SuppressButtonDisk()
        {
            for (int index = 0; index < buttonDisksList.Count(); index++)
            {
                this.Controls.Remove(buttonDisksList[index]);
                buttonDisksList[index].Dispose();
            }

            buttonDisksList.Clear();
        }

        internal void AddButtonDisk()
        {
            int X = 10;
            int Y = 140;
            int ID = 0;
            foreach (DriveInfo i in DriveInfo.GetDrives())
            {
                if (i.IsReady == true)
                {
                    ButtonDisk buttonDisk;

                    if (lang == 0)
                    {
                        buttonDisk = new ButtonDisk(i.Name, (i.TotalFreeSpace / 1000000000) + " Go de libre sur " + (i.TotalSize / 1000000000) + " Go");
                    }
                    else
                    {
                        buttonDisk = new ButtonDisk(i.Name, (i.TotalFreeSpace / 1000000000) + " Go free out of " + (i.TotalSize / 1000000000) + " Go");
                    }
                    buttonDisk.Location = new Point(X, Y);
                    buttonDisk.ID = ID;
                    buttonDisk.EventCliqueID += new EventCliqueIDHandler(ButtonDiskCliqueID);
                    this.Controls.Add(buttonDisk);
                    buttonDisk.BringToFront();
                    buttonDisksList.Add(buttonDisk);

                    ID++;
                    if (X < 330)
                    {
                        X += 250;
                    }
                    else
                    {
                        X = 10;
                        Y = 200;
                    }
                }
            }
        }

        private void ButtonDiskCliqueID(ref int ID)
        {
            ExecuterEvenementPathChanger(new EventExplorerArgs(buttonDisksList[ID].NameDisk));
            explorer(buttonDisksList[ID].NameDisk);
        }
    }

    internal class EventExplorerArgs
    {
        internal string FilePath = string.Empty;

        internal EventExplorerArgs(string FilePathC)
        {
            FilePath = FilePathC;
        }
    }
}
