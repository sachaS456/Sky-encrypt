﻿using System;
using System.Windows.Forms;

namespace Sky_encrypt
{
    internal partial class Loading : Form
    {
        private bool CloseMe = false;

        internal Loading()
        {
            InitializeComponent();
        }

        internal void SetLanguage(sbyte lang)
        {
            if (lang == 0)
            {
                label1.Text = "L'application peut se figer ou ne plus répondre si vous\r\nêtes dans ce cas veuillez patienter!";
            }
            else
            {
                label1.Text = "The application may freeze or no longer respond if this\r\nis the case, please wait!";
            }
        }

        internal void CreateThreadClose()
        {
            CloseMe = false;
            Timer Timer = new Timer();
            Timer.Interval = 10;
            Timer.Tick += new EventHandler(this.timer1_Tick);
            Timer.Enabled = true;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (CloseMe == true)
            {
                this.Close();
            }
        }

        internal bool CloseLoading
        {
            set
            {
                CloseMe = value;
            }
        }
    }
}
