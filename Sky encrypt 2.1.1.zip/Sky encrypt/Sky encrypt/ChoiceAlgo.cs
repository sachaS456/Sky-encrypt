﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sky_encrypt
{
    internal delegate void EventAlgoHandler(ref string e);

    internal partial class ChoiceAlgo : UserControl
    {
        internal EventAlgoHandler EventAlgo = null;
        internal bool Cache { get; private set; } = true;

        internal ChoiceAlgo()
        {
            InitializeComponent();

            this.Size = new Size(this.Size.Width, 0);
            this.Visible = false;
            Cache = true;
        }

        protected virtual void EventAlgoMethode(string e)
        {
            if (EventAlgo != null)
            {
                EventAlgo(ref e);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // AES
            EventAlgoMethode(button3.Text);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // DES
            EventAlgoMethode(button1.Text);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            // RC2
            EventAlgoMethode(button4.Text);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            // TripleDES
            EventAlgoMethode(button5.Text);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (Cache == true)
            {
                this.Visible = true;
                this.Size = new Size(this.Size.Width, this.Size.Height + 15);
                this.Location = new Point(this.Location.X, this.Location.Y - 15);

                if (this.Size.Height >= 107)
                {
                    this.Size = new Size(this.Size.Width, 107);
                    timer1.Enabled = false;
                    Cache = false;
                }
            }
            else
            {
                this.Size = new Size(this.Size.Width, this.Size.Height - 15);
                this.Location = new Point(this.Location.X, this.Location.Y + 15);

                if (this.Size.Height <= 0)
                {
                    this.Size = new Size(this.Size.Width, 0);
                    this.Visible = false;
                    timer1.Enabled = false;
                    Cache = true;
                }
            }
        }

        internal void CacheThis()
        {
            if (Cache == false)
            {
                timer1.Enabled = true;
            }
        }

        internal void MontreThis()
        {
            if (Cache == true)
            {
                timer1.Enabled = true;
            }
        }

        internal sbyte Algo(string Algo)
        {
            switch (Algo)
            {
                case "AES":

                    return Algoritme.AES;

                case "DES":

                    return Algoritme.DES;

                case "RC2":

                    return Algoritme.RC2;

                case "TripleDES":

                    return Algoritme.TripleDES;

                default:

                    return Algoritme.AES;
            }
        }
    }
}
