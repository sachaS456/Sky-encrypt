﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Sky_encrypt
{
    internal partial class FormPrincipal : Form
    {
        private bool FormCache = false;
        private int Coter = 0;
        private bool FormDeplace = false;
        private int LocX = 0;
        private int LocY = 0;
        private const int MiniLargeForm = 400;
        private const int MiniHautForm = 200;
        private sbyte Langue = 0;
        private Explorer explorer1 = new Explorer();
        private Reglage reglage = new Reglage();

        internal FormPrincipal()
        {
            InitializeComponent();

            this.explorer1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.explorer1.Location = new System.Drawing.Point(2, 32);
            this.explorer1.Name = "explorer1";
            this.explorer1.Size = new System.Drawing.Size(791, 321);
            this.explorer1.TabIndex = 14;
            this.panel1.Controls.Add(this.explorer1);
            this.explorer1.PathChanger += new EventExplorerHandler(this.explorer_PathChanger);

            this.Opacity = 0;
            timer1.Enabled = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (this.WindowState == FormWindowState.Maximized)
            {
                this.WindowState = FormWindowState.Normal;
            }
            else
            {
                this.WindowState = FormWindowState.Maximized;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            // animation de form arrêt ou démarre
            if (FormCache == false)
            {
                if (Opacity <= 0.99)
                {
                    Opacity += 0.05;
                }
                else
                {
                    timer1.Enabled = false;
                    FormCache = true;
                }
            }
            else
            {
                if (Opacity >= 0.01)
                {
                    Opacity -= 0.05;
                }
                else
                {
                    timer1.Enabled = false;
                    Environment.Exit(0);
                }
            }
        }

        private void FormPrincipal_FormClosing(object sender, FormClosingEventArgs e)
        {
            timer1.Enabled = true;
            e.Cancel = true;
        }


        private void label1_MouseDown(object sender, MouseEventArgs e)
        {
            // déplacement active car souris préssée
            if (e.Button == MouseButtons.Left && this.Cursor == Cursors.Default)
            {
                LocX = e.X;
                LocY = e.Y;

                FormDeplace = true;
                return;
            }
        }

        private void label1_MouseMove(object sender, MouseEventArgs e)
        {
            // déplacement de la fenêtre
            if (FormDeplace == true)
            {
                this.Location = new Point(MousePosition.X - LocX, MousePosition.Y - LocY);
            }
        }

        private void FormPrincipal_MouseDown(object sender, MouseEventArgs e)
        {
            // déplacement active car souris préssée
            if (e.Button == MouseButtons.Left && this.Cursor == Cursors.Default)
            {
                LocX = e.X;
                LocY = e.Y;

                FormDeplace = true;
                return;
            }

            if (this.Cursor != Cursors.Default)
            {
                /// Coin :

                if (e.X >= this.Size.Width - 2 && e.Y >= this.Size.Height - 2)
                {
                    // agrandit ou réduit coin bas droite
                    Coter = 8;
                    timer2.Enabled = true;
                    return;
                }

                if (e.X <= 2 && e.Y >= this.Size.Height - 2)
                {
                    // agrandit ou réduit coin bas gauche
                    Coter = 7;
                    timer2.Enabled = true;
                    return;
                }

                if (e.X >= this.Size.Width - 2 && e.Y <= 2)
                {
                    // agrandit ou réduit coin haut droite
                    Coter = 5;
                    timer2.Enabled = true;
                    return;
                }

                if (e.X <= 2 && e.Y <= 2)
                {
                    // agrandit ou réduit coin haut gauche
                    Coter = 6;
                    timer2.Enabled = true;
                    return;
                }

                /// cotée :

                if (e.X == 0)
                {
                    // agrandit ou réduit coté gauche

                    Coter = 2;
                    timer2.Enabled = true;
                    return;
                }

                if (e.X == this.Size.Width - 1)
                {
                    // agrandit ou réduit coté droite

                    Coter = 1;
                    timer2.Enabled = true;
                    return;
                }

                if (e.Y == this.Size.Height - 1)
                {
                    // agrandit ou réduit coté bas
                    Coter = 4;
                    timer2.Enabled = true;
                    return;
                }

                if (e.Y == 0)
                {
                    // agrandit ou réduit coté haut
                    Coter = 3;
                    timer2.Enabled = true;
                    return;
                }
            }
        }

        private void FormPrincipal_MouseUp(object sender, MouseEventArgs e)
        {
            timer2.Enabled = false;
            Coter = 0;
            FormDeplace = false;
        }

        private void FormPrincipal_MouseMove(object sender, MouseEventArgs e)
        {
            // déplacement de la fenêtre
            if (FormDeplace == true)
            {
                this.Location = new Point(MousePosition.X - LocX, MousePosition.Y - LocY);
            }

            this.Cursor = Cursors.Default;
            button2.Cursor = Cursors.Default;

            if (e.X >= this.Size.Width - 2 && e.Y >= this.Size.Height - 2)
            {
                // agrandit ou réduit coin bas droite
                this.Cursor = Cursors.SizeNWSE;
                return;
            }

            if (e.X <= 2 && e.Y >= this.Size.Height - 2)
            {
                // agrandit ou réduit coin bas gauche
                this.Cursor = Cursors.SizeNESW;
                return;
            }

            if (e.X <= 2 && e.Y <= 2)
            {
                // agrandit ou réduit coin haut gauche
                this.Cursor = Cursors.SizeNWSE;
                return;
            }

            if (e.X == this.Size.Width - 1)
            {
                // agrandit ou réduit coté droite
                this.Cursor = Cursors.SizeWE;
                button2.Cursor = Cursors.SizeWE;
                return;
            }

            if (e.X == 0)
            {
                // agrandit ou réduit coté gauche
                this.Cursor = Cursors.SizeWE;
                return;
            }

            if (e.Y == this.Size.Height - 1)
            {
                // agrandit ou réduit coté bas
                this.Cursor = Cursors.SizeNS;
                return;
            }

            if (e.Y == 0)
            {
                // agrandit ou réduit coté haut
                this.Cursor = Cursors.SizeNS;
                button2.Cursor = Cursors.SizeNS;
                return;
            }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            switch (Coter)
            {
                case 1:  // côtée droit
                    if (MousePosition.X - this.Location.X >= MiniLargeForm)
                    {
                        this.Size = new Size(MousePosition.X - this.Location.X, this.Size.Height);
                    }
                    else
                    {
                        this.Size = new Size(MiniLargeForm, this.Size.Height);
                    }
                    break;

                case 2: // côtée gauche
                    if (this.Size.Width - (MousePosition.X - this.Location.X) >= MiniLargeForm)
                    {
                        this.Size = new Size(this.Size.Width - (MousePosition.X - this.Location.X), this.Size.Height);
                        this.Location = new Point(MousePosition.X, this.Location.Y);
                    }
                    else
                    {
                        this.Size = new Size(MiniLargeForm, this.Size.Height);
                    }
                    break;

                case 3:  // côtée haut
                    if (this.Size.Height - (MousePosition.Y - this.Location.Y) >= MiniHautForm)
                    {
                        this.Size = new Size(this.Size.Width, this.Size.Height - (MousePosition.Y - this.Location.Y));
                        this.Location = new Point(this.Location.X, MousePosition.Y);
                    }
                    else
                    {
                        this.Size = new Size(this.Size.Width, MiniHautForm);
                    }
                    break;

                case 4:  // côtée bas
                    if (MousePosition.Y - this.Location.Y >= MiniHautForm)
                    {
                        this.Size = new Size(this.Size.Width, MousePosition.Y - this.Location.Y);
                    }
                    else
                    {
                        this.Size = new Size(this.Size.Width, MiniHautForm);
                    }
                    break;

                case 5:  // coin haut droit
                    if (MousePosition.X - this.Location.X >= MiniLargeForm && this.Size.Height - (MousePosition.Y - this.Location.Y) >= MiniHautForm)
                    {
                        this.Size = new Size(MousePosition.X - this.Location.X, this.Size.Height - (MousePosition.Y - this.Location.Y));
                        this.Location = new Point(this.Location.X, MousePosition.Y);
                    }
                    else if (MousePosition.X - this.Location.X >= MiniLargeForm)
                    {
                        this.Size = new Size(MousePosition.X - this.Location.X, MiniHautForm);
                    }
                    else if (this.Size.Height - (MousePosition.Y - this.Location.Y) >= MiniHautForm)
                    {
                        this.Size = new Size(MiniLargeForm, this.Size.Height - (MousePosition.Y - this.Location.Y));
                        this.Location = new Point(this.Location.X, MousePosition.Y);
                    }
                    else
                    {
                        this.Size = new Size(MiniLargeForm, MiniHautForm);
                    }
                    break;

                case 6:  // coin haut gauche
                    if (this.Size.Width - (MousePosition.X - this.Location.X) >= MiniLargeForm && this.Size.Height - (MousePosition.Y - this.Location.Y) >= MiniHautForm)
                    {
                        this.Size = new Size(this.Size.Width - (MousePosition.X - this.Location.X), this.Size.Height - (MousePosition.Y - this.Location.Y));
                        this.Location = new Point(MousePosition.X, MousePosition.Y);
                    }
                    else if (this.Size.Width - (MousePosition.X - this.Location.X) >= MiniLargeForm)
                    {
                        this.Size = new Size(this.Size.Width - (MousePosition.X - this.Location.X), MiniHautForm);
                        this.Location = new Point(MousePosition.X, this.Location.Y);
                    }
                    else if (this.Size.Height - (MousePosition.Y - this.Location.Y) >= MiniHautForm)
                    {
                        this.Size = new Size(MiniLargeForm, this.Size.Height - (MousePosition.Y - this.Location.Y));
                        this.Location = new Point(this.Location.X, MousePosition.Y);
                    }
                    else
                    {
                        this.Size = new Size(MiniLargeForm, MiniHautForm);
                    }
                    break;

                case 7:  // coin bas gauche
                    if (this.Size.Width - (MousePosition.X - this.Location.X) >= MiniLargeForm && MousePosition.Y - this.Location.Y >= MiniHautForm)
                    {
                        this.Size = new Size(this.Size.Width - (MousePosition.X - this.Location.X), MousePosition.Y - this.Location.Y);
                        this.Location = new Point(MousePosition.X, this.Location.Y);
                    }
                    else if (this.Size.Width - (MousePosition.X - this.Location.X) >= MiniLargeForm)
                    {
                        this.Size = new Size(this.Size.Width - (MousePosition.X - this.Location.X), MiniHautForm);
                        this.Location = new Point(MousePosition.X, this.Location.Y);
                    }
                    else if (MousePosition.Y - this.Location.Y >= MiniHautForm)
                    {
                        this.Size = new Size(MiniLargeForm, MousePosition.Y - this.Location.Y);
                    }
                    else
                    {
                        this.Size = new Size(MiniLargeForm, MiniHautForm);
                    }
                    break;

                case 8:  // coin bas droit
                    if (MousePosition.X - this.Location.X >= MiniLargeForm && MousePosition.Y - this.Location.Y >= MiniHautForm)
                    {
                        this.Size = new Size(MousePosition.X - this.Location.X, MousePosition.Y - this.Location.Y);
                    }
                    else if (MousePosition.X - this.Location.X >= MiniLargeForm)
                    {
                        this.Size = new Size(MousePosition.X - this.Location.X, MiniHautForm);
                    }
                    else if (MousePosition.Y - this.Location.Y >= MiniHautForm)
                    {
                        this.Size = new Size(MiniLargeForm, MousePosition.Y - this.Location.Y);
                    }
                    else
                    {
                        this.Size = new Size(MiniLargeForm, MiniHautForm);
                    }
                    break;
            }
        }

        private void button1_MouseMove(object sender, MouseEventArgs e)
        {
            button2.Cursor = Cursors.Default;


            if (e.X >= button1.Size.Width - 2 && e.Y <= 2)
            {
                // agrandit ou réduit coin haut droite
                button1.Cursor = Cursors.SizeNESW;
                return;
            }

            if (e.X == button1.Size.Width - 1)
            {
                // droite
                button1.Cursor = Cursors.SizeWE;
                return;
            }

            if (e.Y == 1)
            {
                // haut
                button1.Cursor = Cursors.SizeNS;
                return;
            }
        }

        private void button1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.X >= button1.Size.Width - 2 && e.Y <= 2)
            {
                // agrandit ou réduit coin haut droite
                Coter = 5;
                timer2.Enabled = true;
                return;
            }

            if (e.X == button1.Size.Width - 2)
            {
                // agrandit ou réduit coté droite

                Coter = 1;
                timer2.Enabled = true;
                return;
            }

            if (e.Y == 1)
            {
                // agrandit ou réduit coté haut
                Coter = 3;
                timer2.Enabled = true;
                return;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            explorer1.explorer(textBox1.Text);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            // chiffrer fichier
            Crypto.Encrypt(explorer1.FichierSelected(), explorer1.CheminFichier, Langue);
            explorer1.explorer(explorer1.CheminFichier);
        }

        private void button9_Click(object sender, EventArgs e)
        {
            // déchiffrer Fichier
            Crypto.Decrypt(explorer1.FichierSelected(), explorer1.CheminFichier, Langue);
            explorer1.explorer(explorer1.CheminFichier);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            // aller dossier avant exploreur
            if (Path.GetDirectoryName(explorer1.CheminFichier) == null)
            {
                explorer1.explorer(string.Empty);
                textBox1.Text = string.Empty;
            }
            else
            {
                textBox1.Text = Path.GetDirectoryName(explorer1.CheminFichier);
                explorer1.explorer(Path.GetDirectoryName(explorer1.CheminFichier));
            }
        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Return)
            {
                explorer1.explorer(textBox1.Text);
            }
        }

        private void explorer_PathChanger(ref EventExplorerArgs e)
        {
            textBox1.Text = e.FilePath;
        }        

        private void button10_Click(object sender, EventArgs e)
        {
            textBox1.Text = string.Empty;
            explorer1.explorer(string.Empty);
        }

        private void button8_Click(object sender, EventArgs e)
        {
            // à propos
            new InfoApp(ref Langue).ShowDialog();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            // réglage
            reglage.Define(ref Langue);

            if (reglage.Save == true)
            {
                if (Directory.Exists(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + @"\Série Sky") == false)
                {
                    Directory.CreateDirectory(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + @"\Série Sky");
                }

                if (Directory.Exists(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + @"\Série Sky\Sky encrypt") == false)
                {
                    Directory.CreateDirectory(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + @"\Série Sky\Sky encrypt");
                }

                StreamWriter writer = new StreamWriter(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + @"\Série Sky\Sky encrypt\appSettings");
                writer.Write(reglage.Language);
                writer.Close();
                writer = null;

                ReglageApplique();
            }
        }

        private void ReglageApplique()
        {
            using (StreamReader reader = new StreamReader(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + @"\Série Sky\Sky encrypt\appSettings"))
            {
                Langue = Convert.ToSByte(reader.ReadLine());
                reader.Close();
            }

            explorer1.lang = Langue;
            explorer1.explorer(textBox1.Text);

            if (Langue == 0)
            {
                button6.Text = "Chiffrer les éléments sélectionnés";
                button9.Text = "Déchiffrer les fichiers sélectionnés";
                button4.Text = "Quitter";
                button5.Text = "Aller à";
                button11.Text = "Réglages";
                button8.Text = "À propos";
            }
            else
            {
                button6.Text = "Encrypt selected items";
                button9.Text = "Decrypt selected files";
                button4.Text = "Leave";
                button5.Text = "Go to";
                button11.Text = "Settings";
                button8.Text = "About";
            }
        }

        private void FormPrincipal_Load(object sender, EventArgs e)
        {
            ReglageApplique();
        }
    }
}
