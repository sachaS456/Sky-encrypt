﻿namespace Sky_encrypt
{
    internal struct Algoritme
    {
        internal const sbyte AES = 0;
        internal const sbyte DES = 1;
        internal const sbyte RC2 = 2;
        internal const sbyte TripleDES = 3;
    }
}
