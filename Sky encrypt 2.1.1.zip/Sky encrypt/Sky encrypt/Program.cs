using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using Sky_updater;
using System.Threading;

namespace Sky_encrypt
{
    public static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        public static void Main()
        {
            Application.SetHighDpiMode(HighDpiMode.DpiUnaware);
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            Thread thread = new Thread(new ThreadStart(CheckUpdate));
            thread.Priority = ThreadPriority.Highest;
            thread.Start();

            if (Directory.Exists(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + @"\S�rie Sky") == false)
            {
                Directory.CreateDirectory(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + @"\S�rie Sky");
            }

            if (Directory.Exists(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + @"\S�rie Sky\Sky encrypt") == false)
            {
                Directory.CreateDirectory(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + @"\S�rie Sky\Sky encrypt");
            }

            if (File.Exists(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + @"\S�rie Sky\Sky encrypt\appSettings") == false)
            {
                StreamWriter writer = new StreamWriter(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + @"\S�rie Sky\Sky encrypt\appSettings");
                writer.Write(1);
                writer.Close();
                writer = null;
            }

            sbyte Langue;

            using (StreamReader reader = new StreamReader(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + @"\S�rie Sky\Sky encrypt\appSettings"))
            {
                Langue = Convert.ToSByte(reader.ReadLine());
                reader.Close();
            }

            if (Path.GetExtension(Environment.GetCommandLineArgs().Last()) == ".ss2se")
            {
                List<string> vs = new List<string>();
                vs.Add(Path.GetFileName(Environment.GetCommandLineArgs().Last()));

                Crypto.Decrypt(vs, Path.GetDirectoryName(Environment.GetCommandLineArgs().Last()), Langue);

                vs.Clear();
                vs = null;
            }
            else
            {
                if (Environment.GetCommandLineArgs().Last() != Application.StartupPath + "Sky encrypt.dll" && Environment.GetCommandLineArgs().Last() != Application.ExecutablePath)
                {
                    List<string> vs = new List<string>();
                    vs.Add(Path.GetFileName(Environment.GetCommandLineArgs().Last()));

                    Crypto.Encrypt(vs, Path.GetDirectoryName(Environment.GetCommandLineArgs().Last()), Langue, true);

                    vs.Clear();
                    vs = null;

                    //MessageBox.Show("Ce fichier n'est pas chiffr� par Sky encrypt!", "Sky encrypt", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Environment.Exit(0);
                    return;
                }

                Application.Run(new FormPrincipal());
            }
        }

        private static void CheckUpdate()
        {
            Update.CheckUpdate("Sky encrypt", Application.ProductVersion);
        }
    }
}
