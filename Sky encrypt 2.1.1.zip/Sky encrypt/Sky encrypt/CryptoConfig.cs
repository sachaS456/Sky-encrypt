﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sky_encrypt
{
    internal class CryptoConfig
    {
        internal readonly string Key;
        internal readonly sbyte Algo;

        internal CryptoConfig(string Key, sbyte Algo)
        {
            this.Key = Key;
            this.Algo = Algo;
        }

        internal static CryptoConfig Empty
        {
            get
            {
                return new CryptoConfig(string.Empty, 0);
            }
        }

        internal bool KeyIsEmpty
        {
            get
            {
                if (Key == string.Empty)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }
    }
}
